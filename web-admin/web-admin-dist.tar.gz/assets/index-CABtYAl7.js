import{c as a}from"./pinia-DcP5Dqpt.js";import"./index-D6NrZd5w.js";const o=a();export{o as default};
