const o="/logo.svg";export{o as _};
